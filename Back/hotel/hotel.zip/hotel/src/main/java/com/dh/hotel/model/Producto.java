package com.dh.hotel.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import com.dh.hotel.model.Caracteristica;

@Getter
@Setter
@Entity
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProducto;
    private String nombre;
    private String tituloDescripcion;
    private String descripcion;

    @OneToOne
    @JoinColumn(name = "categoria_id",referencedColumnName = "idCategoria")
    private Categoria categoria;

    @OneToOne
    @JoinColumn(name = "ciudad_id",referencedColumnName = "idCiudad")
    private Ciudad ciudad;

    @ManyToMany
    @JoinColumn(name = "imagenes_id")
    private List <Imagen> imagen;

    @ManyToMany
    @JoinColumn(name = "caracteristica_id")
    private List <Caracteristica> caracteristica;

    public Producto(){}

    public Producto (String nombre, String descripcion, Categoria categoria, Ciudad ciudad, List <Imagen> imagen, List <Caracteristica> caracteristica){
        this.nombre=nombre;
        this.descripcion=descripcion;
        this.categoria=categoria;
        this.ciudad=ciudad;
        this.imagen=imagen;
        this.caracteristica=caracteristica;
    }

}
