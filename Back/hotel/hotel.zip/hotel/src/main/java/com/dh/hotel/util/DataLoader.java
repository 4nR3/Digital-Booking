package com.dh.hotel.util;

import com.dh.hotel.model.*;
import com.dh.hotel.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataLoader implements ApplicationRunner {

    @Autowired
    private CaracteristicaService caracteristicaService;

    @Autowired
    private CategoriaService categoriaService;

    @Autowired
    private CiudadService ciudadService;

    @Autowired
    private ImagenService imagenService;

    @Autowired
    private ProductoService productoService;

    @Override
    public void run(ApplicationArguments args) throws Exception {

        try{
            Categoria categoria1 = new Categoria("Hosteles", "Hosteles de la zona", "https://media-cdn.tripadvisor.com/media/photo-s/21/91/1a/75/exterior.jpg");
            Categoria categoria2 = new Categoria("Hoteles","Hoteles de la zona","https://cf.bstatic.com/xdata/images/hotel/max1024x768/184305239.jpg?k=2d22fe63ae1f8960e057238c98fb436f7bd9f65854e3a5e918607c5cfa1d0a52&o=&hp=1");
            Categoria categoria3 = new Categoria("Departamentos","Hoteles de la zona","https://www.inmuebles24.com/noticias/wp-content/uploads/2020/01/departamentos-de-lujo-2.jpeg");
            Categoria categoria4 = new Categoria("Bed and breakfast","Hoteles de la zona","https://static.hosteltur.com/app/public/uploads/img/articles/2015/08/01/L_5b14fe49e7f2c_breakfast.jpg");

            categoriaService.agregarCategoria(categoria1);
            categoriaService.agregarCategoria(categoria2);
            categoriaService.agregarCategoria(categoria3);
            categoriaService.agregarCategoria(categoria4);


            Ciudad ciudad1 = new Ciudad("Cordoba","Cordoba","Argentina","https://www.google.com.ar/maps/place/C%C3%B3rdoba/@-31.3994342,-64.2643842,12z/data=!3m1!4b1!4m5!3m4!1s0x9432985f478f5b69:0xb0a24f9a5366b092!8m2!3d-31.4200833!4d-64.1887761?hl=es-419");
            Ciudad ciudad2 = new Ciudad("Rosario","Santa Fe","Argentina","https://www.google.com.ar/maps/place/C%C3%B3rdoba/@-31.3994342,-64.2643842,12z/data=!3m1!4b1!4m5!3m4!1s0x9432985f478f5b69:0xb0a24f9a5366b092!8m2!3d-31.4200833!4d-64.1887761?hl=es-419");
            Ciudad ciudad3 = new Ciudad("Ciudad de Santa Fe","Santa Fe","Argentina","https://www.google.com.ar/maps/place/C%C3%B3rdoba/@-31.3994342,-64.2643842,12z/data=!3m1!4b1!4m5!3m4!1s0x9432985f478f5b69:0xb0a24f9a5366b092!8m2!3d-31.4200833!4d-64.1887761?hl=es-419");
            Ciudad ciudad4 = new Ciudad("La Quiaca","Jujuy","Argentina","https://www.google.com.ar/maps/place/C%C3%B3rdoba/@-31.3994342,-64.2643842,12z/data=!3m1!4b1!4m5!3m4!1s0x9432985f478f5b69:0xb0a24f9a5366b092!8m2!3d-31.4200833!4d-64.1887761?hl=es-419");

            ciudadService.agregarCiudad(ciudad1);
            ciudadService.agregarCiudad(ciudad2);
            ciudadService.agregarCiudad(ciudad3);
            ciudadService.agregarCiudad(ciudad4);

            Caracteristica caracteristica1= new Caracteristica("Wifi","fas fa-wifi");
            Caracteristica caracteristica2= new Caracteristica("Pileta","fas fa-swimmer");
            Caracteristica caracteristica3= new Caracteristica("Parrilla","fas fa-fire");

            caracteristicaService.agregarCaracteristica(caracteristica1);
            caracteristicaService.agregarCaracteristica(caracteristica2);
            caracteristicaService.agregarCaracteristica(caracteristica3);

            List <Caracteristica> listaCaracteristicas = new ArrayList<>();
            listaCaracteristicas.add(caracteristica1);
            listaCaracteristicas.add(caracteristica2);
            listaCaracteristicas.add(caracteristica3);

            Imagen imagen1 = new Imagen("Hotel De Cordoba 1","https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg");
            Imagen imagen2 = new Imagen("Hotel De Cordoba 2","https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg");

            imagenService.subirImagen(imagen1);
            imagenService.subirImagen(imagen2);

            List <Imagen> listaImagenes1 = new ArrayList<>();
            List <Imagen> listaImagenes2 = new ArrayList<>();

            listaImagenes1.add(imagen1);

            listaImagenes2.add(imagen2);

               String descripcion = "En el corazón de San Telmo, disfruta de un albergue inspirado en las pasiones de Buenos Aires";
            String pepiDescripcion= "Veni a jugar al golf con pepi. En el corazon de San Isidro, en el campo de Golf de Pepi";

            Producto producto1 = new Producto("Punta bella",descripcion, categoria1, ciudad1,listaImagenes1, listaCaracteristicas);
            Producto producto2 = new Producto("El gatito",descripcion, categoria2, ciudad2,listaImagenes2, listaCaracteristicas);
            Producto producto3 = new Producto("El perrito",descripcion, categoria3, ciudad3,listaImagenes1, listaCaracteristicas);
            Producto producto4 = new Producto("El hamster",descripcion, categoria4, ciudad4,listaImagenes2, listaCaracteristicas);
            Producto producto5 = new Producto("El caballo",descripcion, categoria1, ciudad4,listaImagenes1, listaCaracteristicas);
            Producto producto6 = new Producto("El pescado",descripcion, categoria2, ciudad3,listaImagenes2, listaCaracteristicas);
            Producto producto7 = new Producto("Sheraton hotel & resort",descripcion, categoria3, ciudad1,listaImagenes1, listaCaracteristicas);
            Producto producto8 = new Producto("PepiGolf",pepiDescripcion, categoria4, ciudad4,listaImagenes2, listaCaracteristicas);

            productoService.agregarProducto(producto1);
            productoService.agregarProducto(producto2);
            productoService.agregarProducto(producto3);
            productoService.agregarProducto(producto4);
            productoService.agregarProducto(producto5);
            productoService.agregarProducto(producto6);
            productoService.agregarProducto(producto7);
            productoService.agregarProducto(producto8);

        }
        catch (Exception e){
            System.out.println(e);
        }

    }
}


/*

            https://media-cdn.tripadvisor.com/media/photo-s/21/91/1a/75/exterior.jpg

            https://cf.bstatic.com/xdata/images/hotel/max1024x768/184305239.jpg?k=2d22fe63ae1f8960e057238c98fb436f7bd9f65854e3a5e918607c5cfa1d0a52&o=&hp=1

            https://www.inmuebles24.com/noticias/wp-content/uploads/2020/01/departamentos-de-lujo-2.jpeg

            https://static.hosteltur.com/app/public/uploads/img/articles/2015/08/01/L_5b14fe49e7f2c_breakfast.jpg

            https://media-cdn.tripadvisor.com/media/photo-s/16/1a/ea/54/hotel-presidente-4s.jpg


 */