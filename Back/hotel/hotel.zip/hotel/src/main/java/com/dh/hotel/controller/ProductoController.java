package com.dh.hotel.controller;

import com.dh.hotel.model.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.dh.hotel.service.ProductoService;

import java.util.List;

@RestController
@RequestMapping("/producto")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping
    public List <Producto> listaDeProductos(){
        return productoService.listarProductos();
    }

    @GetMapping("/{id}")
    public Producto productoPorId(@PathVariable("id")  Long id){
        return productoService.buscarPorId(id);
    }


    @PostMapping
    public Producto guardarProducto(@RequestBody Producto producto){
        return productoService.agregarProducto(producto);
    }

    @PutMapping
    public Producto editarProducto(@RequestBody Producto producto){
        return productoService.modificarProducto(producto);
    }

    @DeleteMapping("/{id}")
    public boolean eliminarProducto(@PathVariable Long id){
        return productoService.eliminarProducto(id);
    }

    @GetMapping
    @RequestMapping("/aleatorios")
    public List <Producto> listaProductosAleatorios(){
        return productoService.listaProductosAleatorios();
    }

    @GetMapping
    @RequestMapping("/ciudad/{id}")
    public List <Producto> listarProductosSegunCiudad(@PathVariable Long id){
        return productoService.listarProductosPorCiudad(id);}

    @GetMapping
    @RequestMapping("/categoria/{id}")
    public List <Producto> listarProductosSegunCategoria(@PathVariable Long id){
        return productoService.listarSegunCategoria(id);
    }
}
