package com.dh.hotel.service;

import com.dh.hotel.model.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dh.hotel.repository.IProductoRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

@Service
public class ProductoService{

    @Autowired
    private IProductoRepository iProducto;

    public Producto agregarProducto(Producto producto){
        return iProducto.save(producto);
    }

    public List <Producto> listarProductos(){
        return iProducto.findAll();
    }

    public Producto buscarPorId(Long id){
        return iProducto.findById(id).get();
    }

    public Producto modificarProducto(Producto producto){
        String Nombre = producto.getNombre();
        String Descripcion = producto.getDescripcion();
        Long id=producto.getIdProducto();

        if(iProducto.findById(id).get()==null)
            return null;

        iProducto.updateById(Nombre,Descripcion,id);

        return iProducto.findById(producto.getIdProducto()).get();
    }

    public boolean eliminarProducto(Long id){
        Producto producto = iProducto.findById(id).get();

        if(producto==null)
            return false;
        else
            iProducto.delete(producto);

        return true;
    }

    public List <Producto> listaProductosAleatorios(){
        List <Producto> listaAleatoria = listarProductos();

        Collections.shuffle(listaAleatoria);

        return listaAleatoria;
    }

    public List <Producto> listarProductosPorCiudad(Long idCiudad){

        return iProducto.listarSegunCiudad(idCiudad);
    }

    public List <Producto> listarSegunCategoria(Long idCategoria){
        return iProducto.listarSegunCategoria(idCategoria);
    }

}
